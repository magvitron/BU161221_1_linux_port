#pragma once
/* DOS Borland BIOS header stub for Linux build.
   Add real replacements only if you later find actual bios* calls. */
