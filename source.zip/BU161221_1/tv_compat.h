// tv_compat.h
#pragma once

#ifndef _NEAR
#define _NEAR
#endif
#ifndef _FAR
#define _FAR
#endif

// Forward decls needed because tobjstrm.h uses these before defining them.
class ipstream;
class opstream;
class TStreamableTypes;

#include <tvision/tobjstrm.h>
