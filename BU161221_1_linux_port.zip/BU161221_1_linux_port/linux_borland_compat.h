// Small compatibility shim for Borland/Turbo C++ keywords when building with GCC/Clang.
#pragma once

// Memory model keywords (DOS/16-bit) -> no-op on modern platforms
#ifndef far
#  define far
#endif
#ifndef near
#  define near
#endif
#ifndef huge
#  define huge
#endif

// Borland ISR calling convention keyword -> no-op for Linux builds
#ifndef interrupt
#  define interrupt
#endif

// Some Borland code expects 'cdecl' keyword
#ifndef cdecl
#  define cdecl
#endif

